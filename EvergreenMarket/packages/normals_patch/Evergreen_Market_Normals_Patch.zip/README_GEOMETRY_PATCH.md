# Evergreen Market: closed-shell winding correction

This patch contains 178 corrected FBX assets from the original 256-asset handoff:

- 138 assets have corrected render-mesh winding: 246 inward closed shells, comprising 45,192 triangles.
- 111 original UBX collision boxes have corrected winding. Of these, 40 assets needed collision-only changes.
- The remaining 78 original FBXs need no replacement for this defect.

## Preservation guarantees

The final FBXs are edited directly from their original binary FBX payloads using Blender 4.3.2's bundled `io_scene_fbx` parser and writer. They are not Blender import/re-export approximations.

For each eligible closed shell, polygon corner order is reversed, UV corner indices are remapped to retain their original vertex associations, and only those corners' original normal vectors are negated. Original shared normal entries are retained; negative copies are added for the selected corners. FBX edge references are remapped while keeping edge order and undirected connectivity unchanged.

Exact parse/write/parse tests pass for all 178 files:

- Vertex coordinates and counts are identical.
- Polygon vertex membership and counts are identical.
- UV layer metadata and vertex-to-UV corner associations are identical.
- Material slots, face assignments, smoothing, transforms, object IDs, connections, textures, and all unrelated FBX payloads are identical.
- Corrected normal vectors match the exact expected sign inversion with zero numerical drift. Unflipped corners' original normal vectors are unchanged.
- All eligible closed-shell volumes are positive after correction.

The selection rule requires a topologically closed and consistently oriented connected shell, with negative signed volume exceeding both an absolute and scale-relative degeneracy threshold. Open shells, positive shells, inconsistent shells and near-zero-volume shells are not blindly flipped. No geometry is welded, moved, remeshed, added or removed.

## Verification and limitations

`qa/fbx_exact_payload.json` is the authoritative, exact FBX attribute test.
`qa/fbx_roundtrip.json` additionally records Blender-import tests for all 178 files: coordinates, bounds, polygon membership, UVs, material associations, transforms and shell volumes all pass.

Blender 4.3's compressed custom-normal reconstruction is lossy on some pre-existing degenerate bevel triangles. Those decoded Blender-normal deviations are recorded separately in the roundtrip report; they are not changes to the delivered FBX normal payload. A reconstructed native `.blend` is deliberately omitted. The original `.blend` remains unchanged.

No tangent buffers are present in the original or patched FBXs. In Unreal, import the corrected normals and regenerate tangents. Do not reuse stale imported tangent buffers. This patch has not been imported or runtime-tested in Unreal in this environment. Collision dimensions and conservative box strategy are unchanged; only their winding is corrected. The patch does not tune collision behavior or change any level placements.

## Files and reproducibility

`patch_manifest.json` maps each original asset ID, relative path and SHA-256 to its corrected FBX SHA-256. It includes per-asset correction and preservation statistics.

The exact-payload builder uses the original handoff plus this patch manifest as its explicit baseline/selection contract:

    blender -b --python source/patch_original_fbx_payload.py -- ORIGINAL_HANDOFF PATCH_FOLDER

Run the independent Blender geometry roundtrip with:

    blender -b --python source/verify_patch_roundtrip.py -- ORIGINAL_HANDOFF PATCH_FOLDER

The original input and patch output must be separate folders. The builder verifies original manifest and asset hashes before rebuilding.

`source/build_supermarket_outward_boxes.py` and `source/convert_supermarket_outward_ubx.py` are corrected copies of the future-generation sources. Their cube face orders are outward. Use them in the original source layout with its existing dependencies. They are not an in-place fix for an already-generated legacy scene: use the delivered FBXs for that case.
