#!/usr/bin/env python3
"""Reproduce the Morrow & Vale fictional grocery label family (Pillow only).
Run: python generate_labels.py
All output is written alongside this script. Textures are 600 x 850 RGB PNGs.
Artwork, labels, and quantities are fictional visual-development assets.
"""
from pathlib import Path
import json, math, random
from PIL import Image, ImageDraw, ImageFont, ImageEnhance

OUT = Path(__file__).resolve().parent
W,H,S = 600,850,2
CREAM = '#F1EAD9'; FOREST = '#294B3D'; TERRA = '#A44936'; NAVY = '#233E53'; GOLD = '#B88942'; INK = '#353A31'
FONTS = {
  'serif': '/usr/share/fonts/opentype/urw-base35/P052-Roman.otf',
  'bold': '/usr/share/fonts/opentype/urw-base35/P052-Bold.otf',
  'italic': '/usr/share/fonts/opentype/urw-base35/P052-Italic.otf',
  'sans': '/usr/share/fonts/truetype/open-sans/OpenSans-Regular.ttf',
  'sansbold': '/usr/share/fonts/truetype/open-sans/OpenSans-Semibold.ttf',
}

def rgb(c): return tuple(int(c[i:i+2],16) for i in (1,3,5))
def font(sz,kind='serif'):
    p=FONTS[kind]
    if not Path(p).exists(): p='/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf' if kind in ('serif','bold','italic') else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    return ImageFont.truetype(p,int(sz*S))

def make_canvas(bg):
    im=Image.new('RGB',(W*S,H*S),bg)
    return im, ImageDraw.Draw(im)

def rect(d,box,fill=None,outline=None,width=1):
    d.rectangle(tuple(round(z*S) for z in box),fill=fill,outline=outline,width=max(1,round(width*S)))
def ellipse(d,box,fill=None,outline=None,width=1):
    d.ellipse(tuple(round(z*S) for z in box),fill=fill,outline=outline,width=max(1,round(width*S)))
def line(d,pts,fill,width=1):
    d.line([(round(x*S),round(y*S)) for x,y in pts],fill=fill,width=max(1,round(width*S)),joint='curve')
def poly(d,pts,fill,outline=None,width=1):
    pp=[(round(x*S),round(y*S)) for x,y in pts]
    d.polygon(pp,fill=fill)
    if outline: d.line(pp+[pp[0]],fill=outline,width=max(1,round(width*S)),joint='curve')
def arc(d,box,start,end,fill,width=1):
    d.arc(tuple(round(z*S) for z in box),start,end,fill=fill,width=max(1,round(width*S)))
def text(d,xy,txt,sz,fill,kind='serif',anchor='mm',max_width=None):
    f=font(sz,kind)
    while max_width and d.textlength(txt,font=f)>max_width*S and sz>10:
        sz-=1; f=font(sz,kind)
    d.text((xy[0]*S,xy[1]*S),txt,font=f,fill=fill,anchor=anchor)
def tracking(d,y,txt,sz,fill,gap=3,x=300):
    f=font(sz,'sansbold'); widths=[d.textlength(c,font=f)/S for c in txt]
    cur=x-(sum(widths)+(len(txt)-1)*gap)/2
    for c,ww in zip(txt,widths):
        d.text((cur*S,y*S),c,font=f,fill=fill,anchor='lm'); cur+=ww+gap

def leaf(d,x,y,length,width,angle,col,vein=None):
    a=math.radians(angle); ux,uy=math.cos(a),math.sin(a); vx,vy=-uy,ux
    pts=[]
    for i in range(17):
        t=i/16; dist=length*t; side=width*.5*math.sin(math.pi*t)
        pts.append((x+ux*dist+vx*side,y+uy*dist+vy*side))
    for i in range(16,-1,-1):
        t=i/16; dist=length*t; side=-width*.5*math.sin(math.pi*t)
        pts.append((x+ux*dist+vx*side,y+uy*dist+vy*side))
    poly(d,pts,col)
    if vein: line(d,[(x,y),(x+ux*length*.9,y+uy*length*.9)],vein,1)

def sprig(d,x,y,length,col,vein,bend=20):
    line(d,[(x,y),(x+bend*.5,y-length*.55),(x+bend,y-length)],col,2)
    for k in range(1,5):
        xx=x+bend*k/5; yy=y-length*k/5
        leaf(d,xx,yy,44,20,220 if k%2 else 315,col,vein)

def badge(d,x,y,txt,col,bg,r=29):
    ellipse(d,(x-r,y-r,x+r,y+r),None,col,1)
    ellipse(d,(x-r+4,y-r+4,x+r-4,y+r-4),None,col,1)
    text(d,(x,y),txt,15,col,'sansbold')

def tomato(d,ink,bg):
    for x,y,r in [(251,496,78),(349,505,69)]:
        ellipse(d,(x-r,y-r,x+r,y+r),TERRA,ink,2)
        for q in [-.45,0,.45]:
            arc(d,(x-r*.6+q*24,y-r*.77,x+r*.6+q*24,y+r*.8),105,258,'#C47855',2)
        for angle in [205,250,295,345,160]: leaf(d,x,y-r+19,49,15,angle,FOREST,bg)
        line(d,[(x,y-r+14),(x+8,y-r-12)],FOREST,5)
    leaf(d,222,542,70,27,205,FOREST,bg)

def chickpeas(d,ink,bg):
    sprig(d,209,585,177,ink,bg,33)
    sprig(d,393,580,171,ink,bg,-29)
    for x,y,r in [(275,490,31),(322,472,34),(334,528,35),(276,548,32),(304,510,30)]:
        ellipse(d,(x-r,y-r,x+r,y+r),'#D8AE6D',ink,2)
        arc(d,(x-r*.35,y-r*.5,x+r*.7,y+r*.7),110,270,ink,2)
        poly(d,[(x-r*.7,y-r*.5),(x-r*.1,y-r*1.13),(x+r*.15,y-r*.55)],'#D8AE6D',ink,1.3)

def bean(d,x,y,rx,ry,col,ink):
    ellipse(d,(x-rx,y-ry,x+rx,y+ry),col,ink,2)
    line(d,[(x+rx*.2,y-ry*.83),(x-rx*.25,y-ry*.2),(x+rx*.25,y+ry*.3),(x-rx*.13,y+ry*.82)],ink,3)
def coffee(d,ink,bg):
    sprig(d,237,583,169,'#83927E',bg,60)
    sprig(d,366,580,164,'#83927E',bg,-36)
    for x,y in [(273,475),(322,512),(267,551),(345,463)]: bean(d,x,y,25,35,'#BC8751',CREAM)
    for x,y in [(235,473),(374,529),(332,408)]: ellipse(d,(x-10,y-10,x+10,y+10),'#B95B41',CREAM,1)

def olive(d,ink,bg):
    line(d,[(225,588),(264,529),(300,479),(358,414)],ink,4)
    for x,y,a,l in [(248,554,210,67),(271,520,330,78),(294,486,211,71),(319,458,335,67),(343,428,264,49)]:
        leaf(d,x,y,l,22,a,'#6C7D52',CREAM)
    for x,y in [(263,546),(302,507),(330,454)]:
        ellipse(d,(x-18,y-26,x+18,y+26),'#344E31',ink,2)
        arc(d,(x-10,y-17,x+12,y+15),170,260,'#819063',2)

def flowers(d,ink,bg):
    for x,y in [(241,466),(357,452),(275,534),(337,539)]:
        line(d,[(300,597),(x,y)],'#657A4C',2)
        for i in range(8):
            a=i*math.pi/4; xx=x+17*math.cos(a); yy=y+17*math.sin(a)
            ellipse(d,(xx-9,yy-14,xx+9,yy+14),CREAM,ink,1)
        ellipse(d,(x-10,y-10,x+10,y+10),'#C78139',ink,1)
    leaf(d,283,561,53,19,198,'#657A4C',CREAM)
    leaf(d,315,572,60,20,326,'#657A4C',CREAM)
    # small beekeeper's emblem
    ellipse(d,(293,414,318,436),CREAM,ink,1)
    ellipse(d,(315,414,339,436),CREAM,ink,1)
    ellipse(d,(304,424,329,458),'#C78139',ink,2)
    for yy in [436,444]: line(d,[(306,yy),(327,yy)],ink,3)

def strawberry(d,ink,bg):
    for x,y,s in [(258,480,1.0),(345,518,.85)]:
        pts=[(x-62*s,y-31*s),(x-49*s,y-61*s),(x-9*s,y-63*s),(x+22*s,y-66*s),(x+60*s,y-40*s),(x+60*s,y-8*s),(x+44*s,y+35*s),(x,y+88*s),(x-43*s,y+35*s),(x-61*s,y-6*s)]
        poly(d,pts,'#AC3C38',ink,2)
        for row in range(5):
            yy=y-28*s+row*20*s
            for col in range(4-row//2):
                xx=x-(29-row*3)*s+col*20*s
                ellipse(d,(xx-2*s,yy-3*s,xx+2*s,yy+3*s),'#F0CA8A')
        for a in [180,225,270,315,355]: leaf(d,x,y-52*s,44*s,17*s,a,FOREST,CREAM)
    leaf(d,286,420,72,33,318,FOREST,CREAM)

def grain(d,x,y,height,col,ink):
    line(d,[(x,y),(x+8,y-height)],ink,2)
    for k in range(6):
        yy=y-48-k*21; xx=x+8*(y-yy)/height
        leaf(d,xx,yy,40,16,224,col,ink)
        leaf(d,xx,yy-5,40,16,310,col,ink)
    line(d,[(x+8,y-height+14),(x+10,y-height-18)],ink,1)
def oats(d,ink,bg):
    grain(d,263,597,169,'#C99C56',ink)
    grain(d,332,590,190,'#C99C56',ink)
    leaf(d,277,580,82,19,245,'#77805B',CREAM)
    leaf(d,328,576,84,19,316,'#77805B',CREAM)

def almond(d,ink,bg):
    # almond kernels and a gently curved botanical branch
    line(d,[(204,578),(274,538),(345,493),(397,442)],ink,2)
    for x,y,a in [(252,552,231),(297,524,303),(351,483,234)]: leaf(d,x,y,61,24,a,'#76815B',CREAM)
    for x,y,a in [(270,470,69),(324,535,111),(349,449,120)]:
        leaf(d,x,y,76,43,a,'#B47743',ink)
        rr=math.radians(a)
        for shift in [-6,0,6]:
            line(d,[(x+shift+10*math.cos(rr),y+10*math.sin(rr)),(x+shift+66*math.cos(rr),y+66*math.sin(rr))],'#E4BD82',1)
    for x,y in [(224,495),(232,513),(371,552),(389,538),(345,580)]: ellipse(d,(x-8,y-6,x+8,y+6),'#C99858',ink,1)

def pasta(d,ink,bg):
    # bronze-die rigatoni, with engraved ridges
    for x,y,ww,hh in [(230,442,59,108),(307,474,60,106),(366,426,54,103)]:
        poly(d,[(x-ww/2,y),(x+ww/2,y),(x+ww/2-13,y+hh),(x-ww/2-13,y+hh)],'#D6A958',ink,2)
        ellipse(d,(x-ww/2,y-12,x+ww/2,y+12),'#EDC87E',ink,2)
        ellipse(d,(x-ww*.30,y-6,x+ww*.30,y+6),ink)
        for dd in [-15,-5,5,15]:line(d,[(x+dd,y+15),(x+dd-10,y+hh-4)],'#F3CF88',2)
    grain(d,210,593,103,'#B48442',ink)

def salt(d,ink,bg):
    # maritime horizon and mineral crystals
    for yy in [487,506,525,544]:
        pts=[(198+i*4,yy+5*math.sin(i*.38)) for i in range(52)]
        line(d,pts,ink,2)
    arc(d,(269,417,331,479),182,358,'#B78D58',3)
    line(d,[(197,476),(404,476)],ink,2)
    for x,y,size in [(261,582,28),(311,567,35),(354,590,20)]:
        poly(d,[(x,y-size),(x+size,y-size*.3),(x+size*.6,y+size*.6),(x-size*.5,y+size*.8),(x-size,y-size*.2)],CREAM,ink,2)
        line(d,[(x,y-size),(x+3,y),(x-size*.5,y+size*.8)],ink,1)
        line(d,[(x+3,y),(x+size,y-size*.3)],ink,1)

ITEMS = [
 dict(sku='crushed_tomatoes',name='Crushed Tomatoes',title=['Crushed','Tomatoes'],category='THE GOOD PANTRY',desc='Vine-ripened. Simply prepared.',detail='TOMATOES • TOMATO JUICE • SEA SALT',weight='NET WT 14.1 OZ / 400 g',accent=TERRA,bg=CREAM,ink=FOREST,body='#A44936',art='tomato',kind='can'),
 dict(sku='chickpeas',name='Tender Chickpeas',title=['Tender','Chickpeas'],category='EVERYDAY ESSENTIALS',desc='Earthy, nutty & beautifully tender.',detail='CHICKPEAS • WATER • SEA SALT',weight='NET WT 14.1 OZ / 400 g',accent=FOREST,bg='#EAE3CD',ink=FOREST,body='#55715B',art='chickpeas',kind='can'),
 dict(sku='coffee',name='Morning Blend Coffee',title=['Morning','Blend'],category='SMALL BATCH COFFEE',desc='Cocoa · toasted hazelnut · caramel',detail='WHOLE BEAN • MEDIUM ROAST',weight='NET WT 8.8 OZ / 250 g',accent='#B98750',bg=NAVY,ink=CREAM,body=NAVY,art='coffee',kind='can'),
 dict(sku='olive_oil',name='Extra Virgin Olive Oil',title=['Extra Virgin','Olive Oil'],category='THE OLIVE GROVE',desc='First cold extraction. Full of character.',detail='100% EXTRA VIRGIN OLIVE OIL',weight='16.9 FL OZ / 500 mL',accent=FOREST,bg=CREAM,ink=FOREST,body='#34472B',art='olive',kind='bottle'),
 dict(sku='wildflower_honey',name='Wildflower Honey',title=['Wildflower','Honey'],category='FROM FIELD & FLOWER',desc='Floral, golden & naturally sweet.',detail='PURE WILDFLOWER HONEY',weight='NET WT 12 OZ / 340 g',accent='#8A562C',bg='#E8CB83',ink='#65472E',body='#B5792F',art='flowers',kind='jar'),
 dict(sku='strawberry_preserve',name='Strawberry Preserve',title=['Strawberry','Preserve'],category='THE FRUIT KITCHEN',desc='A little summer, carefully preserved.',detail='STRAWBERRIES • CANE SUGAR • LEMON',weight='NET WT 10 OZ / 284 g',accent='#9B403B',bg=CREAM,ink='#713B36',body='#8C3B38',art='strawberry',kind='jar'),
 dict(sku='rolled_oats',name='Old-fashioned Rolled Oats',title=['Rolled','Oats'],category='A SLOWER MORNING',desc='Whole grain. Comfort in every bowl.',detail='OLD-FASHIONED • 100% WHOLE GRAIN',weight='NET WT 18 OZ / 510 g',accent=FOREST,bg='#EDE6D4',ink=FOREST,body=FOREST,art='oats',kind='box'),
 dict(sku='almond_granola',name='Toasted Almond Granola',title=['Almond','Granola'],category='A SLOWER MORNING',desc='Toasted oats, almonds & golden honey.',detail='CRISP CLUSTERS • SMALL BATCH BAKED',weight='NET WT 12 OZ / 340 g',accent='#AD623E',bg='#EAD8B7',ink='#604332',body='#AD623E',art='almond',kind='box'),
 dict(sku='bronze_pasta',name='Bronze-cut Rigatoni Pasta',title=['Bronze-cut','Rigatoni'],category='THE ITALIAN TABLE',desc='A generous shape for your finest sauce.',detail='DURUM WHEAT SEMOLINA • SLOW DRIED',weight='NET WT 17.6 OZ / 500 g',accent=NAVY,bg='#EDDFB7',ink=NAVY,body=NAVY,art='pasta',kind='box'),
 dict(sku='sea_salt',name='Flaky Sea Salt',title=['Flaky','Sea Salt'],category='FROM THE OPEN SEA',desc='Delicate crystals. A perfect finish.',detail='PURE SEA SALT • HAND HARVESTED',weight='NET WT 5.3 OZ / 150 g',accent=NAVY,bg='#E7E6DC',ink=NAVY,body=NAVY,art='salt',kind='box'),
]
ART = dict(tomato=tomato,chickpeas=chickpeas,coffee=coffee,olive=olive,flowers=flowers,strawberry=strawberry,oats=oats,almond=almond,pasta=pasta,salt=salt)


def create_label(item,index):
    bg,ink,accent=item['bg'],item['ink'],item['accent']
    im,d=make_canvas(bg)
    # Slim double keyline gives the collection a vintage grocer's-label structure.
    rect(d,(22,22,578,828),outline=accent,width=1.5)
    rect(d,(29,29,571,821),outline=accent,width=.6)
    tracking(d,60,'MORROW & VALE',29,ink,2.7)
    tracking(d,96,'G O O D   T H I N G S ,   W E L L   M A D E',9,ink,.4)
    line(d,[(69,124),(250,124)],accent,1)
    line(d,[(350,124),(531,124)],accent,1)
    text(d,(300,126),'M / V',20,accent,'italic')
    tracking(d,168,item['category'],14,accent,2.5)
    # Oversized names are deliberately centered above the product illustration.
    for j,t in enumerate(item['title']):
        text(d,(300,238+j*74),t,72,ink,'serif',max_width=490)
    line(d,[(258,364),(342,364)],accent,1)
    ellipse(d,(297,361,303,367),accent)
    ART[item['art']](d,ink,bg)
    text(d,(300,639),item['desc'],22,ink,'italic',max_width=485)
    tracking(d,678,item['detail'],12,ink,1.4)
    # Solid, cropped-at-the-bottom band reads clearly even in shelf renders.
    rect(d,(29,715,571,821),fill=accent)
    band_ink=CREAM
    tracking(d,743,'PANTRY NO. '+str(index+1).zfill(2),11,band_ink,2.2)
    text(d,(300,781),item['weight'],22,band_ink,'sansbold',max_width=485)
    im=im.resize((W,H),Image.Resampling.LANCZOS)
    # Restrained deterministic paper variation, never enough to blur the typography.
    rng=random.Random(731+index)
    px=im.load()
    for yy in range(H):
        for xx in range(W):
            delta=rng.choice([-2,-1,0,0,0,1,2])
            c=px[xx,yy]; px[xx,yy]=tuple(max(0,min(255,v+delta)) for v in c)
    im.save(OUT/(item['sku']+'.png'),optimize=True)
    return im


def main():
    all_specs={}; images=[]
    for i,item in enumerate(ITEMS):
        images.append(create_label(item,i))
        spec={
          'sku':item['sku'], 'filename':item['sku']+'.png',
          'display_name':item['name'], 'brand':'Morrow & Vale',
          'pixel_dimensions':[W,H], 'color_space':'sRGB', 'image_mode':'RGB',
          'packaging_type':item['kind'],
          'palette_rgb':{'paper':list(rgb(item['bg'])),'ink':list(rgb(item['ink'])),'accent':list(rgb(item['accent'])),'suggested_body':list(rgb(item['body']))},
          'dimensions_hint':{'aspect_ratio':round(W/H,6),'safe_margin_px':29,'front_label_only':True},
          'material_hint':'Use PNG as base color on a front decal or front-panel UV; body color is separate. Suggested paper roughness 0.68.',
          'fictional_product':True
        }
        all_specs[item['sku']]=spec
        (OUT/(item['sku']+'.json')).write_text(json.dumps(spec,indent=2)+'\n')
    (OUT/'label_specs.json').write_text(json.dumps({'brand':'Morrow & Vale','version':1,'generator':'generate_labels.py','labels':all_specs},indent=2)+'\n')
    # This sheet is solely a convenient review artifact; use individual PNGs for UVs.
    sheet=Image.new('RGB',(5*300+6*24,2*425+3*24),'#D3CEC2')
    for i,im in enumerate(images): sheet.paste(im.resize((300,425),Image.Resampling.LANCZOS),(24+(i%5)*324,24+(i//5)*449))
    sheet.save(OUT/'label_contact_sheet.jpg',quality=95)
    print('Created 10 label PNGs, 10 per-SKU specs, label_specs.json, and label_contact_sheet.jpg in '+str(OUT))

if __name__=='__main__': main()
