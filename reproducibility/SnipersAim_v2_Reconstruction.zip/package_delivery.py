from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parent;O=R/'output';D=R/'delivery';D.mkdir(exist_ok=True);f=O/'SnipersAim_Dense_Canyon_v2.blend';digest=hashlib.sha256(f.read_bytes()).hexdigest();size=f.stat().st_size
# Update documentation to final firing stance and data counts.
p=O/'READ_ME.txt';t=p.read_text().replace('SNIPER_EYE=(0,88,23.55)','SNIPER_EYE=(0,85.8,23.55)').replace('116 visible mesh objects share16 unique mesh datablocks: the15 supplied models plus ground.','119 visible mesh objects share19 unique mesh datablocks: the15 supplied models, ground, and three simple authored firing-balcony pieces.').replace('The tower deck was measured at z≈21.964 m, with sniper eye at23.55 m.','The tower deck and added forward firing balcony were measured at z≈21.964 m, with sniper eye at23.55 m. The added3.2x4 m steel balcony allows a supported stance ahead of the original top rail, keeping the near approach visible.');p.write_text(t)
p=R/'REBUILD.txt';t=p.read_text().replace('blender -b -t 4 --python export_validate.py','blender -b -t 6 --python add_firing_balcony.py\nblender -b -t 4 --python export_validate.py').replace('1c3637b54e1eb41ede87c71b610c7ca0e3a20923d834ca2ff5dc06063bcd0a2e',digest);p.write_text(t)
# Update manifest with custom balcony geometry and final elevated rifle placement.
p=O/'Layout_Manifest.json';m=json.loads(p.read_text());m=[r for r in m if not r.get('generated_geometry')]
for r in m:
 if r['object']=='Sniper display rifle':r['position']=[0,86.5,22.2];r['unity_position_xyz']=[0,22.2,86.5]
for name,loc,dims in [('Sniper firing balcony',(0,86,21.8536),(3.2,4,.22)),('Balcony left stringer',(-1.35,86.1,21.65),(.18,4.5,.25)),('Balcony right stringer',(1.35,86.1,21.65),(.18,4.5,.25))]:m.append({'object':name,'source_id':None,'generated_geometry':'cube','position':loc,'dimensions_xyz':dims,'unity_position_xyz':[loc[0],loc[2],loc[1]],'unity_dimensions_xyz':[dims[0],dims[2],dims[1]],'material':'Balcony dark steel'})
p.write_text(json.dumps(m,indent=2))
parts=[];partsize=15*1024*1024
with f.open('rb') as src:
 i=1
 while True:
  data=src.read(partsize)
  if not data:break
  partname=f.name+f'.part{i:03d}';zpath=D/f'SnipersAim_v2_Part_{i:02d}.zip'
  with zipfile.ZipFile(zpath,'w',zipfile.ZIP_STORED) as z:z.writestr(partname,data)
  with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
  parts.append({'zip':str(zpath),'part':partname,'bytes':len(data),'zip_bytes':zpath.stat().st_size});i+=1
manifest={'filename':f.name,'bytes':size,'sha256':digest,'parts':parts};(D/'Parts_Manifest.json').write_text(json.dumps(manifest,indent=2))
ps=r'''$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$name = 'SnipersAim_Dense_Canyon_v2.blend'
$expected = '__HASH__'
$target = Join-Path $root $name
if (Test-Path $target) { throw 'The blend already exists. Move or rename it before assembling again.' }
$parts = 1..__COUNT__ | ForEach-Object { Join-Path $root ($name + ('.part{0:D3}' -f $_)) }
foreach ($p in $parts) { if (!(Test-Path $p)) { throw "Missing part: $p. Extract all part ZIPs into this same folder first." } }
$temp = $target + '.assembling'
if (Test-Path $temp) { throw 'A temporary assembly already exists. Rename or remove it before trying again.' }
$out = [System.IO.File]::Create($temp)
try {
  foreach ($p in $parts) {
    $inputStream = [System.IO.File]::OpenRead($p)
    try { $inputStream.CopyTo($out) } finally { $inputStream.Dispose() }
  }
} finally { $out.Dispose() }
$actual = (Get-FileHash -LiteralPath $temp -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actual -ne $expected) { throw 'Checksum mismatch. The temporary file is incomplete or damaged. Redownload the part ZIPs; do not open it as the scene.' }
Move-Item -LiteralPath $temp -Destination $target
Write-Host "Success: exact Blender file reconstructed and SHA256 verified: $target"
'''.replace('__HASH__',digest).replace('__COUNT__',str(len(parts)))
(D/'Reassemble.ps1').write_text(ps)
py='''from pathlib import Path
import hashlib,shutil
r=Path(__file__).resolve().parent
name="SnipersAim_Dense_Canyon_v2.blend"
parts=[r/(name+f".part{i:03d}") for i in range(1,COUNT+1)]
for p in parts:
 if not p.is_file():raise SystemExit(f"Missing {p.name}; extract every part ZIP into this folder.")
out=r/name;tmp=r/(name+".assembling")
if out.exists() or tmp.exists():raise SystemExit("Output or temporary file already exists; move it aside before reassembly.")
with tmp.open("wb") as dst:
 for p in parts:
  with p.open("rb") as src:shutil.copyfileobj(src,dst)
if hashlib.sha256(tmp.read_bytes()).hexdigest()!="HASH":raise SystemExit("Checksum mismatch: redownload damaged/missing parts.")
tmp.rename(out);print("Success: exact Blender file restored and SHA256 verified.")
'''.replace('COUNT',str(len(parts))).replace('HASH',digest)
(D/'reassemble.py').write_text(py)
(D/'START_HERE.txt').write_text(f'''SNIPERSAIM V2 — RESTORE YOUR BLENDER FILE\n\n1. Download all {len(parts)} Part ZIPs plus this Instructions ZIP.\n2. Extract every ZIP into the SAME folder. The folder should contain Reassemble.ps1 and {len(parts)} files ending .part001 through .part{len(parts):03d}. Do not leave each part inside its own nested folder.\n3. On Windows, open PowerShell in that folder and run:\n   .\\Reassemble.ps1\n   If your Windows policy blocks an unsigned script, you can instead run the supplied Python3 alternative: python reassemble.py. Do not change your security policy just for this file.\n4. The script creates {f.name} and verifies its SHA256 checksum. Open that file in Blender.\n\nmacOS/Linux with Python3: python3 reassemble.py\n\nThis restores all {size:,} original bytes, with no quality reduction. These are ordinary ZIP containers holding binary chunks; do not open an individual chunk in Blender. No specialized multipart archive tool is required. Keep your reconstructed blend and reconstruction backup in storage you control.\n\nSHA256: {digest}\n''')
with zipfile.ZipFile(D/'SnipersAim_v2_Instructions.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in [D/'Reassemble.ps1',D/'reassemble.py',D/'START_HERE.txt',D/'Parts_Manifest.json',O/'READ_ME.txt']:z.write(p,p.name)
# Reconstruct the archive contents in memory-streaming order and verify exact bytes.
h=hashlib.sha256();total=0
for r in parts:
 with zipfile.ZipFile(r['zip']) as z:
  data=z.read(r['part']);h.update(data);total+=len(data)
assert h.hexdigest()==digest and total==size
# Reproducibility archive does not include originals; pinned source is documented.
with zipfile.ZipFile(R/'SnipersAim_v2_Reconstruction.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in list(R.glob('*.py'))+[R/'REBUILD.txt']+list(O.glob('*.json'))+[O/'READ_ME.txt']:z.write(p,p.relative_to(R).as_posix())
for p in [D/'SnipersAim_v2_Instructions.zip',R/'SnipersAim_v2_Reconstruction.zip']:
 with zipfile.ZipFile(p) as z:assert z.testzip() is None
print(json.dumps(manifest,indent=2),flush=True)
